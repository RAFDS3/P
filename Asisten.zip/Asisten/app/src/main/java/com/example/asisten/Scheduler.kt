package com.example.asisten

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.*
import java.util.Calendar
import java.util.concurrent.TimeUnit

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("rem", "Pengingat", NotificationManager.IMPORTANCE_HIGH))
        nm.notify(System.currentTimeMillis().toInt(), Notification.Builder(ctx, "rem")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Asisten").setContentText(i.getStringExtra("msg")).setAutoCancel(true).build())
    }
}

object Scheduler {
    /** 5: jadwalkan notifikasi pada jam tertentu. */
    fun schedule(ctx: Context, msg: String, h: Int, m: Int, id: Boolean): String {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        val pi = PendingIntent.getBroadcast(ctx, (cal.timeInMillis / 1000).toInt(),
            Intent(ctx, ReminderReceiver::class.java).putExtra("msg", msg),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val am = ctx.getSystemService(AlarmManager::class.java)
        if (am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        val t = "%02d:%02d".format(h, m)
        return if (id) "Siap, saya akan mengingatkan \"$msg\" pukul $t." else "Done, I'll remind you \"$msg\" at $t."
    }

    /** 11: optimalisasi otomatis saat perangkat idle & mengisi daya. */
    fun scheduleOptimize(ctx: Context) {
        val req = PeriodicWorkRequestBuilder<OptimizeWorker>(1, TimeUnit.DAYS)
            .setConstraints(Constraints.Builder().setRequiresDeviceIdle(true).setRequiresCharging(true).build()).build()
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("optimize", ExistingPeriodicWorkPolicy.KEEP, req)
    }
}

class OptimizeWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
    override fun doWork(): Result {
        val old = System.currentTimeMillis() - 24L * 3600 * 1000
        applicationContext.cacheDir.walkBottomUp().filter { it.isFile && it.lastModified() < old }.forEach { it.delete() }
        System.gc()
        return Result.success()
    }
}
