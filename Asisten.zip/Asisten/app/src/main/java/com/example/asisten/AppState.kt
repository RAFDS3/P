package com.example.asisten

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

data class Msg(val text: String, val user: Boolean, val image: String? = null)

enum class VoiceState { IDLE, LISTENING, THINKING, SPEAKING }

/** Status UI global (bertahan selama proses aplikasi hidup). */
object AppState {
    val messages = mutableStateListOf<Msg>()
    var themeMode by mutableStateOf(0)            // 0 = ikuti sistem, 1 = terang, 2 = gelap
    var welcomeDone by mutableStateOf(false)
    var busy by mutableStateOf(false)

    var voiceState by mutableStateOf(VoiceState.IDLE)
    var voiceText by mutableStateOf("")
    var voiceLevel by mutableStateOf(0f)

    var attached by mutableStateOf<Uri?>(null)
    var attachedName by mutableStateOf("")
    var attachedIsImage by mutableStateOf(false)

    var modelReady by mutableStateOf(false)
    var modelSizeMb by mutableStateOf(0L)
    var modelProgress by mutableStateOf(-1f)      // -1 = tidak sedang menyalin
    var modelNote by mutableStateOf("")

    fun load(ctx: Context) {
        val sp = ctx.getSharedPreferences("ui", Context.MODE_PRIVATE)
        themeMode = sp.getInt("theme", 0)
        welcomeDone = sp.getBoolean("welcome", false)
        refreshModel(ctx)
    }

    fun refreshModel(ctx: Context) {
        modelReady = Llm.available(ctx)
        modelSizeMb = if (modelReady) Llm.modelFile(ctx).length() / 1048576L else 0L
    }

    fun saveTheme(ctx: Context) {
        ctx.getSharedPreferences("ui", Context.MODE_PRIVATE).edit().putInt("theme", themeMode).apply()
    }

    fun saveWelcome(ctx: Context) {
        welcomeDone = true
        ctx.getSharedPreferences("ui", Context.MODE_PRIVATE).edit().putBoolean("welcome", true).apply()
    }

    /** Balasan bergambar memakai penanda [[img:path]]teks. */
    fun parseReply(r: String): Pair<String?, String> {
        if (r.startsWith("[[img:")) {
            val end = r.indexOf("]]")
            if (end > 0) return r.substring(6, end) to r.substring(end + 2).trim()
        }
        return null to r
    }
}
