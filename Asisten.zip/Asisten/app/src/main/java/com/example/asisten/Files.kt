package com.example.asisten

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.util.zip.ZipInputStream

object Files {
    fun name(ctx: Context, u: Uri): String =
        ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
        } ?: "file"

    private fun size(ctx: Context, u: Uri): Long =
        ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getLong(c.getColumnIndexOrThrow(OpenableColumns.SIZE)) else 0L
        } ?: 0L

    private fun zipText(ctx: Context, u: Uri, match: (String) -> Boolean, rx: Regex): String {
        val sb = StringBuilder()
        ZipInputStream(ctx.contentResolver.openInputStream(u)).use { z ->
            var e = z.nextEntry
            while (e != null) {
                if (match(e.name)) {
                    val xml = z.readBytes().decodeToString()
                    rx.findAll(xml).forEach { sb.append(it.groupValues[1]).append(". ") }
                    sb.append('\n')
                }
                e = z.nextEntry
            }
        }
        return sb.toString().replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
    }

    /** 14: ekstrak teks PDF / PPTX / XLSX / teks biasa. */
    fun extract(ctx: Context, u: Uri): String? = try {
        when (name(ctx, u).substringAfterLast('.', "").lowercase()) {
            "pdf" -> { PDFBoxResourceLoader.init(ctx)
                PDDocument.load(ctx.contentResolver.openInputStream(u)).use { PDFTextStripper().getText(it) } }
            "pptx" -> zipText(ctx, u, { it.startsWith("ppt/slides/slide") && it.endsWith(".xml") }, Regex("<a:t>(.*?)</a:t>"))
            "xlsx" -> zipText(ctx, u, { it == "xl/sharedStrings.xml" }, Regex("<t[^>]*>(.*?)</t>"))
            "txt", "csv", "md", "json", "log" -> ctx.contentResolver.openInputStream(u)!!.bufferedReader().readText()
            else -> null
        }
    } catch (e: Exception) { null }

    private val stop = setOf("yang","dengan","untuk","dari","pada","adalah","this","that","with","from","have","will","dan","itu","ini")
    private fun freq(text: String) = text.lowercase().split(Regex("\\W+")).filter { it.length > 3 && it !in stop }
        .groupingBy { it }.eachCount()

    /** Ringkasan ekstraktif: ambil kalimat dengan skor kata tertinggi. */
    fun summarize(text: String, id: Boolean): String {
        val f = freq(text)
        val sents = text.split(Regex("(?<=[.!?])\\s+|\\n+")).map { it.trim() }.filter { it.length > 25 }
        if (sents.isEmpty()) return if (id) "Teks terlalu pendek/kosong." else "Text too short/empty."
        val top = sents.withIndex().sortedByDescending { (_, s) ->
            s.lowercase().split(Regex("\\W+")).sumOf { f[it] ?: 0 }.toDouble() / (s.length + 20) }.take(5).sortedBy { it.index }
        return (if (id) "Ringkasan:\n" else "Summary:\n") + top.joinToString("\n") { "• " + it.value }
    }

    /** 6: analisis dasar file. */
    fun analyze(ctx: Context, u: Uri, text: String, id: Boolean): String {
        val kw = freq(text).entries.sortedByDescending { it.value }.take(8).joinToString { "${it.key} (${it.value})" }
        val words = text.split(Regex("\\s+")).count { it.isNotBlank() }
        return if (id) "Analisis ${name(ctx, u)}:\n• Ukuran: ${size(ctx, u) / 1024} KB\n• Kata: $words\n• Karakter: ${text.length}\n• Kata kunci: $kw"
        else "Analysis of ${name(ctx, u)}:\n• Size: ${size(ctx, u) / 1024} KB\n• Words: $words\n• Characters: ${text.length}\n• Keywords: $kw"
    }
}
