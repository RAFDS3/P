@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.asisten

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

// ---------------------------------------------------------------- Tema (terang / gelap)

@Composable
fun AsistenTheme(content: @Composable () -> Unit) {
    val dark = when (AppState.themeMode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val scheme = if (dark) darkColorScheme(
        primary = Color(0xFF8AB4F8), onPrimary = Color(0xFF062E6F),
        primaryContainer = Color(0xFF2A3F63), onPrimaryContainer = Color(0xFFE3EBFF),
        background = Color(0xFF131418), onBackground = Color(0xFFE6E8EC),
        surface = Color(0xFF131418), onSurface = Color(0xFFE6E8EC),
        surfaceVariant = Color(0xFF22252B), onSurfaceVariant = Color(0xFFD5D8DE)
    ) else lightColorScheme(
        primary = Color(0xFF1A73E8), onPrimary = Color(0xFFFFFFFF),
        primaryContainer = Color(0xFFD7E3FF), onPrimaryContainer = Color(0xFF0B2A5B),
        background = Color(0xFFFFFFFF), onBackground = Color(0xFF1B1C20),
        surface = Color(0xFFFFFFFF), onSurface = Color(0xFF1B1C20),
        surfaceVariant = Color(0xFFF0F2F5), onSurfaceVariant = Color(0xFF44474F)
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

// ---------------------------------------------------------------- Akar aplikasi

@Composable
fun AsistenApp(ctl: Controller) {
    val ctx = LocalContext.current
    var screen by remember { mutableStateOf(0) }          // 0 = chat, 1 = suara
    var showModel by remember { mutableStateOf(false) }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) ctl.attach(uri)
    }
    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) ctl.installModel(uri)
    }
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) { screen = 1; ctl.startListen() } else ctl.toast("Izin mikrofon ditolak")
    }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        if (!AppState.welcomeDone) {
            WelcomeScreen { ctl.finishWelcome() }
        } else if (screen == 1) {
            VoiceScreen(ctl) { ctl.stopVoice(); screen = 0 }
        } else {
            ChatScreen(
                ctl = ctl,
                onVoice = {
                    val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                    if (granted) { screen = 1; ctl.startListen() } else micPerm.launch(Manifest.permission.RECORD_AUDIO)
                },
                onModel = { showModel = true },
                onPickFile = { filePicker.launch(arrayOf("*/*")) }
            )
        }
        if (showModel) {
            ModelDialog(ctl, onPick = { modelPicker.launch(arrayOf("*/*")) }, onDismiss = { showModel = false })
        }
    }
}

// ---------------------------------------------------------------- Layar sambutan

@Composable
fun WelcomeScreen(onStart: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier.size(96.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) { Text("🤖", fontSize = 48.sp) }
        Spacer(Modifier.height(24.dp))
        Text("Selamat datang!", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Asisten pribadi yang berjalan langsung di HP Anda.",
            textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(24.dp))
        listOf(
            "🎤  Bicara dalam Indonesia & Inggris",
            "🌐  Cari informasi di internet",
            "📎  Ringkas PDF, PPT, dan Excel",
            "🖼  Perbaiki foto & buat gambar AI",
            "🧠  Jawaban generatif offline"
        ).forEach { Text(it, modifier = Modifier.padding(vertical = 5.dp), fontSize = 15.sp) }
        Spacer(Modifier.height(32.dp))
        Button(onClick = onStart, modifier = Modifier.fillMaxWidth()) { Text("Mulai") }
    }
}

// ---------------------------------------------------------------- Layar chat

@Composable
fun ChatScreen(ctl: Controller, onVoice: () -> Unit, onModel: () -> Unit, onPickFile: () -> Unit) {
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val msgs = AppState.messages

    LaunchedEffect(msgs.size, AppState.busy) {
        val last = msgs.size + (if (AppState.busy) 1 else 0) - 1
        if (last >= 0) listState.animateScrollToItem(last)
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Asisten", fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            IconButton(onClick = { ctl.newChat() }) { Text("🗑") }
            IconButton(onClick = onModel) { Text(if (AppState.modelReady) "🧠" else "⚠️") }
            IconButton(onClick = { ctl.cycleTheme() }) {
                Text(
                    when (AppState.themeMode) {
                        1 -> "☀️"
                        2 -> "🌙"
                        else -> "🌓"
                    }
                )
            }
        }

        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            if (msgs.isEmpty()) {
                EmptyState(ctl)
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(msgs) { m -> Bubble(m) }
                    if (AppState.busy) item { TypingBubble() }
                }
            }
        }

        if (AppState.attached != null) AttachmentBar(ctl)

        Row(
            modifier = Modifier.fillMaxWidth().padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onPickFile) { Text("📎", fontSize = 22.sp) }
            TextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Tulis pesan…") },
                shape = RoundedCornerShape(26.dp),
                maxLines = 4,
                colors = TextFieldDefaults.colors(
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    disabledIndicatorColor = Color.Transparent
                )
            )
            Spacer(Modifier.width(6.dp))
            if (input.isBlank()) {
                FilledIconButton(onClick = onVoice) { Text("🎤") }
            } else {
                FilledIconButton(onClick = { ctl.send(input); input = "" }) { Text("➤") }
            }
        }
    }
}

@Composable
fun EmptyState(ctl: Controller) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Halo! 👋", fontSize = 34.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text("Apa yang bisa saya bantu hari ini?", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(24.dp))
        Column(verticalArrangement = Arrangement.spacedBy(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Pill("🌦  Cuaca di Tokyo") { ctl.send("cuaca di Tokyo") }
            Pill("🔎  Berita teknologi terbaru") { ctl.send("berita teknologi terbaru") }
            Pill("🎨  Buat gambar kucing astronot") { ctl.send("buat gambar kucing astronot di bulan") }
            Pill("⏰  Ingatkan saya minum obat pukul 20:00") { ctl.send("ingatkan saya minum obat pukul 20:00") }
        }
    }
}

@Composable
fun Pill(text: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Surface(
        shape = shape,
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.clip(shape).clickable { onClick() }
    ) {
        Text(text, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp), fontSize = 14.sp)
    }
}

private fun loadThumb(path: String): ImageBitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, bounds)
    var sample = 1
    while (bounds.outWidth / sample > 1400) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    return BitmapFactory.decodeFile(path, opts)?.asImageBitmap()
}

@Composable
fun Bubble(m: Msg) {
    val cs = MaterialTheme.colorScheme
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (m.user) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = if (m.user) cs.primaryContainer else cs.surfaceVariant,
            modifier = Modifier.widthIn(max = 330.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                val path = m.image
                if (path != null) {
                    val bmp = remember(path) { loadThumb(path) }
                    if (bmp != null) {
                        Image(
                            bitmap = bmp, contentDescription = null,
                            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                        )
                        Spacer(Modifier.height(8.dp))
                    }
                }
                if (m.text.isNotBlank()) {
                    SelectionContainer {
                        Text(m.text, color = if (m.user) cs.onPrimaryContainer else cs.onSurfaceVariant, fontSize = 15.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun TypingBubble() {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
        Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
            Text("Sedang berpikir…", modifier = Modifier.padding(12.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun AttachmentBar(ctl: Controller) {
    Column(modifier = Modifier.padding(horizontal = 12.dp)) {
        Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
            Row(
                modifier = Modifier.padding(start = 12.dp, end = 4.dp, top = 2.dp, bottom = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("📎 " + AppState.attachedName, modifier = Modifier.weight(1f, fill = false), maxLines = 1)
                IconButton(onClick = { ctl.clearAttachment() }) { Text("✕") }
            }
        }
        Row(modifier = Modifier.padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (AppState.attachedIsImage) {
                Pill("🖼  Perbaiki foto") { ctl.processPhoto() }
            } else {
                Pill("📝  Ringkas") { ctl.send("ringkas file") }
                Pill("📊  Analisis") { ctl.send("analisis file") }
            }
        }
    }
}

// ---------------------------------------------------------------- Layar suara

@Composable
fun VoiceScreen(ctl: Controller, onClose: () -> Unit) {
    val st = AppState.voiceState
    val scale by animateFloatAsState(
        targetValue = if (st == VoiceState.LISTENING) 1f + (AppState.voiceLevel.coerceIn(0f, 10f) / 25f) else 1f,
        label = "mic"
    )
    Column(modifier = Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(modifier = Modifier.fillMaxWidth()) {
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onClose) { Text("Tutup ✕") }
        }
        Spacer(Modifier.weight(1f))
        Text(
            when (st) {
                VoiceState.LISTENING -> "Mendengarkan…"
                VoiceState.THINKING -> "Berpikir…"
                VoiceState.SPEAKING -> "Berbicara…"
                VoiceState.IDLE -> "Ketuk mikrofon untuk bicara"
            },
            fontSize = 20.sp, fontWeight = FontWeight.Medium
        )
        Spacer(Modifier.height(12.dp))
        Text(
            AppState.voiceText,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        Spacer(Modifier.height(36.dp))
        Box(
            modifier = Modifier.size(150.dp).scale(scale).clip(CircleShape)
                .background(if (st == VoiceState.LISTENING) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.primaryContainer)
                .clickable { ctl.toggleListen() },
            contentAlignment = Alignment.Center
        ) { Text("🎤", fontSize = 56.sp) }
        Spacer(Modifier.weight(1f))
        Text("Bahasa Indonesia & English", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
    }
}

// ---------------------------------------------------------------- Dialog pemasangan model

@Composable
fun ModelDialog(ctl: Controller, onPick: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Tutup") } },
        title = { Text("Model AI generatif") },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    if (AppState.modelReady) "✅ Model terpasang (${AppState.modelSizeMb} MB)"
                    else "⚠️ Belum ada model. Tanpa model, asisten menjawab lewat pencarian web."
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    "1. Unduh model Gemma 3 1B (.task, sekitar 555 MB) dari Hugging Face (perlu login dan setuju lisensi).\n" +
                        "2. Tekan \"Pilih file model\" lalu pilih file .task dari folder Download.",
                    fontSize = 13.sp
                )
                if (AppState.modelProgress >= 0f) {
                    Spacer(Modifier.height(10.dp))
                    LinearProgressIndicator(progress = { AppState.modelProgress }, modifier = Modifier.fillMaxWidth())
                    Text("${(AppState.modelProgress * 100).toInt()}%", fontSize = 13.sp)
                }
                if (AppState.modelNote.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text(AppState.modelNote, fontSize = 13.sp)
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onPick, enabled = AppState.modelProgress < 0f) { Text("Pilih file model") }
                    OutlinedButton(onClick = { ctl.openModelPage() }) { Text("Unduh") }
                }
                if (AppState.modelReady) {
                    TextButton(onClick = { ctl.deleteModel() }) { Text("Hapus model") }
                }
            }
        }
    )
}
