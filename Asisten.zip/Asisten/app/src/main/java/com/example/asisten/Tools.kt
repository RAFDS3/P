package com.example.asisten

import android.content.Context
import android.content.Intent
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object Tools {
    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "AsistenApp/1.0")
        return c.inputStream.bufferedReader().use { it.readText() }
    }
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    /** 3 & 12: buka aplikasi berdasarkan nama. */
    fun openApp(ctx: Context, name: String): Boolean {
        val pm = ctx.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val app = pm.queryIntentActivities(q, 0)
            .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name.lowercase()) } ?: return false
        val i = pm.getLaunchIntentForPackage(app.activityInfo.packageName) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i); return true
    }

    private fun wx(c: Int, id: Boolean) = when (c) {
        0 -> if (id) "cerah" else "clear"
        1, 2 -> if (id) "berawan sebagian" else "partly cloudy"
        3 -> if (id) "berawan" else "overcast"
        in 45..48 -> if (id) "berkabut" else "fog"
        in 51..67 -> if (id) "gerimis/hujan" else "drizzle/rain"
        in 71..77 -> if (id) "salju" else "snow"
        in 80..82 -> if (id) "hujan lebat" else "rain showers"
        in 95..99 -> if (id) "badai petir" else "thunderstorm"
        else -> "-"
    }

    /** 4: cuaca seluruh dunia via Open-Meteo (tanpa API key). */
    fun weather(city: String, id: Boolean): String {
        val g = JSONObject(get("https://geocoding-api.open-meteo.com/v1/search?name=${enc(city)}&count=1&language=${if (id) "id" else "en"}"))
        val r = g.optJSONArray("results")?.optJSONObject(0)
            ?: return if (id) "Kota '$city' tidak ditemukan." else "City '$city' not found."
        val cur = JSONObject(get("https://api.open-meteo.com/v1/forecast?latitude=${r.getDouble("latitude")}&longitude=${r.getDouble("longitude")}" +
            "&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code")).getJSONObject("current")
        val place = "${r.getString("name")}, ${r.optString("country")}"
        val d = wx(cur.getInt("weather_code"), id)
        return if (id) "Cuaca di $place: $d, ${cur.getDouble("temperature_2m")}°C, kelembapan ${cur.getInt("relative_humidity_2m")}%, angin ${cur.getDouble("wind_speed_10m")} km/j."
        else "Weather in $place: $d, ${cur.getDouble("temperature_2m")}°C, humidity ${cur.getInt("relative_humidity_2m")}%, wind ${cur.getDouble("wind_speed_10m")} km/h."
    }

    /** 2: cari informasi otomatis via Wikipedia (bahasa mengikuti bahasa pengguna). */
    fun search(q: String, id: Boolean): String {
        try {
            val lang = if (id) "id" else "en"
            val s = JSONObject(get("https://$lang.wikipedia.org/w/api.php?action=query&list=search&srsearch=${enc(q)}&format=json&srlimit=1"))
            val hit = s.getJSONObject("query").getJSONArray("search").optJSONObject(0)
            if (hit == null) return if (id) "Tidak ada hasil untuk '$q'." else "No results for '$q'."
            val title = hit.getString("title")
            return JSONObject(get("https://$lang.wikipedia.org/api/rest_v1/page/summary/${enc(title.replace(' ', '_'))}")).getString("extract")
        } catch (e: Exception) {
            return if (id) "Gagal terhubung ke internet: ${e.message}" else "Couldn't reach the internet: ${e.message}"
        }
    }
}
