package com.example.asisten

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import java.net.HttpURLConnection
import java.net.URL

object Net {
    fun online(ctx: Context): Boolean {
        val cm = ctx.getSystemService(ConnectivityManager::class.java) ?: return false
        val net = cm.activeNetwork ?: return false
        val cap = cm.getNetworkCapabilities(net) ?: return false
        return cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
}

object Http {
    const val UA = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    /** Ambil teks (dibatasi ukurannya agar hemat data & memori). */
    fun get(url: String, max: Int = 400_000, timeout: Int = 9000): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = timeout
        c.readTimeout = timeout
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", UA)
        c.setRequestProperty("Accept-Language", "id,en;q=0.8")
        return c.inputStream.bufferedReader().use { r ->
            val buf = CharArray(8192)
            val sb = StringBuilder()
            while (sb.length < max) {
                val n = r.read(buf)
                if (n < 0) break
                sb.append(buf, 0, n)
            }
            sb.toString()
        }
    }

    /** Unduh gambar; null bila bukan gambar. */
    fun image(url: String): ByteArray? {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 90000
        c.setRequestProperty("User-Agent", UA)
        if (c.responseCode != 200) return null
        if (c.contentType?.startsWith("image") != true) return null
        return c.inputStream.use { it.readBytes() }
    }
}
