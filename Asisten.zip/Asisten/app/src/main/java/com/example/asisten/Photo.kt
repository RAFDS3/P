package com.example.asisten

import android.content.Context
import android.graphics.*
import android.net.Uri
import android.os.Environment
import java.io.File
import kotlin.math.max
import kotlin.math.min

/**
 * 13 & 15: decode foto (termasuk RAW/DNG bila didukung perangkat), perbaiki otomatis,
 * dan belajar "selera" pengguna dari foto-foto yang diberikan (rata-rata kecerahan & saturasi).
 */
object Photo {
    private fun stats(b: Bitmap): Pair<Float, Float> {
        var l = 0f; var s = 0f; var n = 0
        val stp = max(1, min(b.width, b.height) / 64)
        for (y in 0 until b.height step stp) for (x in 0 until b.width step stp) {
            val p = b.getPixel(x, y)
            val r = Color.red(p) / 255f; val g = Color.green(p) / 255f; val bl = Color.blue(p) / 255f
            val mx = max(r, max(g, bl)); val mn = min(r, min(g, bl))
            l += 0.2126f * r + 0.7152f * g + 0.0722f * bl
            s += if (mx == 0f) 0f else (mx - mn) / mx; n++
        }
        return l / n to s / n
    }

    fun process(ctx: Context, uri: Uri): String {
        val src = ImageDecoder.createSource(ctx.contentResolver, uri)
        val bmp = ImageDecoder.decodeBitmap(src) { d, _, _ ->
            d.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE); d.setTargetSampleSize(2) }
        val (lum, sat) = stats(bmp)

        val sp = ctx.getSharedPreferences("photo_style", Context.MODE_PRIVATE)
        val n = sp.getInt("n", 0)
        val tLum = if (n >= 3) sp.getFloat("lum", 0.5f) else 0.5f
        val tSat = if (n >= 3) sp.getFloat("sat", 0.4f) else 0.4f
        val gain = (tLum / max(lum, 0.05f)).coerceIn(0.6f, 1.8f)
        val satScale = (tSat / max(sat, 0.05f)).coerceIn(0.8f, 1.4f)

        val cm = ColorMatrix().apply { setSaturation(satScale) }
        cm.postConcat(ColorMatrix(floatArrayOf(gain,0f,0f,0f,0f, 0f,gain,0f,0f,0f, 0f,0f,gain,0f,0f, 0f,0f,0f,1f,0f)))
        val out = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
        Canvas(out).drawBitmap(bmp, 0f, 0f, Paint().apply { colorFilter = ColorMatrixColorFilter(cm) })

        val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_PICTURES)!!
        val f = File(dir, "edit_${System.currentTimeMillis()}.jpg")
        f.outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 92, it) }

        // Belajar dari foto yang diberikan pengguna (rata-rata berjalan)
        sp.edit().putInt("n", n + 1)
            .putFloat("lum", (sp.getFloat("lum", lum) * n + lum) / (n + 1))
            .putFloat("sat", (sp.getFloat("sat", sat) * n + sat) / (n + 1)).apply()
        return "${f.absolutePath}|${n + 1}"
    }
}
