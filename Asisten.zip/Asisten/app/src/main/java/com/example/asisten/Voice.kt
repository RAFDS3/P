package com.example.asisten

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Input suara (SpeechRecognizer) + keluaran suara (TextToSpeech), Indonesia & Inggris. */
class Voice(private val ctx: Context, private val onResult: (String) -> Unit) {
    private var sr: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null

    init {
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("id", "ID")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { AppState.voiceState = VoiceState.SPEAKING }
                    override fun onDone(utteranceId: String?) { AppState.voiceState = VoiceState.IDLE }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { AppState.voiceState = VoiceState.IDLE }
                })
            }
        }
    }

    fun listen(idLang: Boolean) {
        tts?.stop()
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            AppState.voiceText = "Pengenalan suara tidak tersedia di perangkat ini."
            return
        }
        sr?.destroy()
        val rec = SpeechRecognizer.createSpeechRecognizer(ctx)
        sr = rec
        rec.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { AppState.voiceState = VoiceState.LISTENING }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) { AppState.voiceLevel = v }
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(e: Int) {
                AppState.voiceState = VoiceState.IDLE
                AppState.voiceText = if (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT)
                    "Tidak terdengar. Ketuk mic untuk mencoba lagi." else "Mic error ($e)"
            }
            override fun onResults(r: Bundle?) {
                val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t.isNullOrBlank()) {
                    AppState.voiceState = VoiceState.IDLE
                } else {
                    AppState.voiceText = t
                    onResult(t)
                }
            }
            override fun onPartialResults(p: Bundle?) {
                p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { AppState.voiceText = it }
            }
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (idLang) "id-ID" else "en-US")
            .putExtra("android.speech.extra.ADDITIONAL_LANGUAGES", arrayOf("id-ID", "en-US"))
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        rec.startListening(i)
    }

    fun speak(text: String, id: Boolean) {
        val clean = text.replace(Regex("https?://\\S+"), "").replace(Regex("[*#_`•]"), "").take(900)
        tts?.language = if (id) Locale("id", "ID") else Locale.US
        AppState.voiceState = VoiceState.SPEAKING
        tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    fun stopListening() { sr?.stopListening() }
    fun stopSpeaking() { tts?.stop() }

    fun stop() {
        tts?.stop()
        sr?.cancel()
        AppState.voiceState = VoiceState.IDLE
    }

    fun shutdown() {
        sr?.destroy()
        tts?.shutdown()
    }
}
