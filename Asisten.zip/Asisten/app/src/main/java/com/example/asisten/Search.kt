package com.example.asisten

import android.text.Html
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

data class Hit(val title: String, val url: String, val snippet: String)

/** Pencarian multi-mesin: DuckDuckGo -> Bing -> Wikipedia (cadangan), dengan cache 10 menit. */
object Search {
    private val cache = ConcurrentHashMap<String, Pair<Long, List<Hit>>>()
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun clean(s: String): String =
        Html.fromHtml(s, Html.FROM_HTML_MODE_LEGACY).toString().replace(Regex("\\s+"), " ").trim()

    fun all(q: String, id: Boolean): List<Hit> {
        val key = (if (id) "id:" else "en:") + q.lowercase()
        cache[key]?.let { if (System.currentTimeMillis() - it.first < 600_000L) return it.second }
        var r: List<Hit> = runCatching { ddg(q, id) }.getOrDefault(emptyList())
        if (r.isEmpty()) r = runCatching { bing(q, id) }.getOrDefault(emptyList())
        if (r.isEmpty()) r = runCatching { wiki(q, id) }.getOrDefault(emptyList())
        if (r.isNotEmpty()) cache[key] = System.currentTimeMillis() to r
        return r
    }

    private fun realUrl(h: String): String {
        val m = Regex("uddg=([^&]+)").find(h)
        val u = if (m != null) URLDecoder.decode(m.groupValues[1], "UTF-8") else h
        return if (u.startsWith("//")) "https:$u" else u
    }

    private fun ddg(q: String, id: Boolean): List<Hit> {
        val html = Http.get("https://html.duckduckgo.com/html/?q=${enc(q)}&kl=${if (id) "id-id" else "us-en"}")
        val links = Regex("<a[^>]*class=\"result__a\"[^>]*href=\"([^\"]+)\"[^>]*>(.*?)</a>", RegexOption.DOT_MATCHES_ALL).findAll(html).toList()
        val snips = Regex("<a[^>]*class=\"result__snippet\"[^>]*>(.*?)</a>", RegexOption.DOT_MATCHES_ALL).findAll(html).toList()
        return links.take(6).mapIndexedNotNull { i, m ->
            val url = realUrl(m.groupValues[1])
            if (url.isBlank() || url.contains("duckduckgo.com/y.js")) null
            else Hit(clean(m.groupValues[2]), url, clean(snips.getOrNull(i)?.groupValues?.get(1) ?: ""))
        }
    }

    private fun bing(q: String, id: Boolean): List<Hit> {
        val html = Http.get("https://www.bing.com/search?q=${enc(q)}&setlang=${if (id) "id" else "en"}")
        val item = Regex("<li class=\"b_algo\".*?<h2[^>]*><a[^>]*href=\"([^\"]+)\"[^>]*>(.*?)</a></h2>(.*?)</li>", RegexOption.DOT_MATCHES_ALL)
        val para = Regex("<p[^>]*>(.*?)</p>", RegexOption.DOT_MATCHES_ALL)
        return item.findAll(html).take(6).map { m ->
            Hit(clean(m.groupValues[2]), m.groupValues[1], clean(para.find(m.groupValues[3])?.groupValues?.get(1) ?: ""))
        }.toList()
    }

    private fun wiki(q: String, id: Boolean): List<Hit> {
        val lang = if (id) "id" else "en"
        val j = org.json.JSONObject(Http.get("https://$lang.wikipedia.org/w/api.php?action=query&list=search&srsearch=${enc(q)}&format=json&srlimit=4"))
        val arr = j.getJSONObject("query").getJSONArray("search")
        val out = ArrayList<Hit>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val title = o.getString("title")
            out.add(Hit(title, "https://$lang.wikipedia.org/wiki/" + enc(title.replace(' ', '_')), clean(o.optString("snippet"))))
        }
        return out
    }

    /** Ambil isi paragraf dari sebuah halaman web. */
    fun pageText(url: String, max: Int): String = try {
        val html = Http.get(url, max = 250_000)
        val body = html.replace(Regex("(?is)<(script|style|nav|footer|header|noscript)[^>]*>.*?</\\1>"), " ")
        val paras = Regex("(?is)<p[^>]*>(.*?)</p>").findAll(body).map { clean(it.groupValues[1]) }.filter { it.length > 60 }.joinToString(" ")
        (if (paras.isNotBlank()) paras else clean(body)).take(max)
    } catch (e: Exception) { "" }

    /** Susun konteks ringkas untuk model (snippet + isi 2 halaman teratas, diambil paralel). */
    suspend fun context(hits: List<Hit>): String = coroutineScope {
        val pages = hits.take(2).map { h -> async(Dispatchers.IO) { pageText(h.url, 700) } }.awaitAll()
        val sb = StringBuilder()
        hits.take(4).forEachIndexed { i, h -> sb.append("[${i + 1}] ${h.title}: ${h.snippet}\n") }
        pages.forEachIndexed { i, p -> if (p.isNotBlank()) sb.append("Isi [${i + 1}]: $p\n") }
        sb.toString().take(2200)
    }
}
