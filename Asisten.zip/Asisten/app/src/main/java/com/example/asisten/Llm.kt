package com.example.asisten

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.io.File

/** AI generatif on-device (offline) memakai MediaPipe LLM Inference + model Gemma. */
object Llm {
    private var engine: LlmInference? = null
    private val history = ArrayDeque<Pair<String, String>>()

    fun modelFile(ctx: Context) = File(ctx.filesDir, "model.task")
    fun available(ctx: Context): Boolean = modelFile(ctx).let { it.exists() && it.length() > 10_000_000L }

    @Synchronized fun reset() {
        try { engine?.close() } catch (e: Throwable) { }
        engine = null
        history.clear()
    }

    @Synchronized fun clearHistory() { history.clear() }

    @Synchronized private fun ensure(ctx: Context): LlmInference {
        engine?.let { return it }
        val e = LlmInference.createFromOptions(ctx, LlmInference.LlmInferenceOptions.builder()
            .setModelPath(modelFile(ctx).absolutePath).setMaxTokens(1280).build())
        engine = e
        return e
    }

    @Synchronized fun chat(ctx: Context, q: String, facts: String, id: Boolean, extra: String = ""): String {
        val lang = if (id) "bahasa Indonesia" else "English"
        val sb = StringBuilder("<start_of_turn>user\n")
        sb.append("Kamu adalah asisten pribadi yang ramah dan ringkas. Selalu jawab dalam $lang.")
        if (facts.isNotBlank()) sb.append(" Fakta yang diajarkan pengguna: ${facts.take(400)}.")
        sb.append("<end_of_turn>\n")
        if (extra.isBlank()) {
            for ((u, a) in history) sb.append("<start_of_turn>user\n$u<end_of_turn>\n<start_of_turn>model\n$a<end_of_turn>\n")
        }
        val question = if (extra.isBlank()) q
        else "Gunakan hasil pencarian web berikut untuk menjawab. Jika tidak cukup, katakan tidak tahu.\n\n$extra\n\nPertanyaan: $q"
        sb.append("<start_of_turn>user\n$question<end_of_turn>\n<start_of_turn>model\n")
        val out = ensure(ctx).generateResponse(sb.toString()).trim()
        if (extra.isBlank()) {
            history.addLast(q.take(200) to out.take(300))
            while (history.size > 2) history.removeFirst()
        }
        return out
    }

    @Synchronized fun once(ctx: Context, prompt: String): String =
        ensure(ctx).generateResponse("<start_of_turn>user\n$prompt<end_of_turn>\n<start_of_turn>model\n").trim()
}
