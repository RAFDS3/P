package com.example.asisten

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.io.File

/** AI generatif on-device (offline) memakai MediaPipe LLM Inference + model Gemma. */
object Llm {
    private var engine: LlmInference? = null
    private val history = ArrayDeque<Pair<String, String>>()

    fun modelFile(ctx: Context) = File(ctx.filesDir, "model.task")
    fun available(ctx: Context) = modelFile(ctx).exists()

    @Synchronized fun reset() { engine?.close(); engine = null; history.clear() }

    @Synchronized fun chat(ctx: Context, q: String, facts: String, id: Boolean): String {
        if (engine == null) {
            engine = LlmInference.createFromOptions(ctx, LlmInference.LlmInferenceOptions.builder()
                .setModelPath(modelFile(ctx).absolutePath).setMaxTokens(1024).build())
        }
        val lang = if (id) "bahasa Indonesia" else "English"
        val sb = StringBuilder("<start_of_turn>user\n")
        sb.append("Kamu adalah asisten pribadi yang ramah dan ringkas. Selalu jawab dalam $lang.")
        if (facts.isNotBlank()) sb.append(" Fakta yang diajarkan pengguna: $facts.")
        sb.append("<end_of_turn>\n")
        for ((u, a) in history) sb.append("<start_of_turn>user\n$u<end_of_turn>\n<start_of_turn>model\n$a<end_of_turn>\n")
        sb.append("<start_of_turn>user\n$q<end_of_turn>\n<start_of_turn>model\n")
        val out = engine!!.generateResponse(sb.toString()).trim()
        history.addLast(q to out); if (history.size > 3) history.removeFirst()
        return out
    }
}
