package com.example.asisten

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Penghubung antara UI (Compose) dan otak/alat asisten. */
class Controller(private val act: ComponentActivity) {
    private val brain = Brain(act)
    private val scope = MainScope()
    private val voice = Voice(act) { text -> send(text, true) }

    fun toast(t: String) { Toast.makeText(act, t, Toast.LENGTH_SHORT).show() }

    // ---- chat
    fun send(text: String, fromVoice: Boolean = false) {
        if (text.isBlank() || AppState.busy) return
        AppState.messages.add(Msg(text, true))
        AppState.busy = true
        if (fromVoice) AppState.voiceState = VoiceState.THINKING
        scope.launch {
            val r = try { brain.handle(text) } catch (e: Throwable) { "Error: ${e.message}" }
            AppState.busy = false
            val (img, body) = AppState.parseReply(r)
            AppState.messages.add(Msg(body, false, img))
            if (fromVoice) voice.speak(body, brain.id) else AppState.voiceState = VoiceState.IDLE
        }
    }

    fun newChat() { AppState.messages.clear(); Llm.clearHistory() }

    fun cycleTheme() { AppState.themeMode = (AppState.themeMode + 1) % 3; AppState.saveTheme(act) }

    fun finishWelcome() { AppState.saveWelcome(act) }

    // ---- suara
    fun startListen() { AppState.voiceText = ""; voice.listen(brain.id) }

    fun toggleListen() {
        when (AppState.voiceState) {
            VoiceState.LISTENING -> voice.stopListening()
            VoiceState.THINKING -> { }
            else -> startListen()
        }
    }

    fun stopVoice() { voice.stop() }

    // ---- file
    fun attach(uri: Uri) {
        val name = Files.name(act, uri)
        val ext = name.substringAfterLast('.', "").lowercase()
        val mime = act.contentResolver.getType(uri) ?: ""
        AppState.attached = uri
        AppState.attachedName = name
        AppState.attachedIsImage = mime.startsWith("image/") ||
            ext in setOf("dng", "raw", "cr2", "nef", "arw", "jpg", "jpeg", "png", "webp", "heic")
        brain.lastFile = uri
    }

    fun clearAttachment() { AppState.attached = null; brain.lastFile = null }

    fun processPhoto() {
        val u = AppState.attached ?: return
        if (AppState.busy) return
        AppState.messages.add(Msg("🖼 Perbaiki foto: " + AppState.attachedName, true))
        AppState.busy = true
        scope.launch {
            val r = withContext(Dispatchers.Default) {
                try { Photo.process(act, u) } catch (e: Throwable) { "ERR|" + e.message }
            }
            AppState.busy = false
            val parts = r.split("|")
            if (parts[0] == "ERR") {
                AppState.messages.add(Msg("Gagal memproses foto: " + parts.getOrNull(1) +
                    ". (Format RAW tertentu mungkin tidak didukung perangkat ini.)", false))
            } else {
                AppState.messages.add(Msg("Foto diperbaiki otomatis dan disimpan.\nFoto yang sudah dipelajari: " +
                    parts.getOrNull(1), false, parts[0]))
            }
            clearAttachment()
        }
    }

    // ---- model
    fun installModel(uri: Uri) {
        val fname = Files.name(act, uri).lowercase()
        if (!(fname.endsWith(".task") || fname.endsWith(".bin") || fname.endsWith(".litertlm"))) {
            AppState.modelNote = "File harus berformat .task (bukan .safetensors)."
            return
        }
        AppState.modelProgress = 0f
        AppState.modelNote = "Menyalin model… jangan tutup aplikasi."
        scope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    Llm.reset()
                    val total = Files.size(act, uri).coerceAtLeast(1L)
                    val dest = Llm.modelFile(act)
                    act.contentResolver.openInputStream(uri)!!.use { input ->
                        dest.outputStream().use { out ->
                            val buf = ByteArray(1 shl 20)
                            var done = 0L
                            var n = 0
                            while (input.read(buf).also { n = it } >= 0) {
                                out.write(buf, 0, n)
                                done += n
                                AppState.modelProgress = (done.toFloat() / total).coerceIn(0f, 1f)
                            }
                        }
                    }
                    true
                } catch (e: Throwable) { false }
            }
            AppState.modelProgress = -1f
            AppState.refreshModel(act)
            AppState.modelNote = if (ok && AppState.modelReady) "Model terpasang. Sekarang saya bisa menjawab secara generatif (offline)."
            else "Gagal menyalin model."
        }
    }

    fun deleteModel() {
        Llm.reset()
        Llm.modelFile(act).delete()
        AppState.refreshModel(act)
        AppState.modelNote = "Model dihapus."
    }

    fun openModelPage() {
        act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://huggingface.co/litert-community/Gemma3-1B-IT")))
    }

    fun destroy() { scope.cancel(); voice.shutdown() }
}

class MainActivity : ComponentActivity() {
    private lateinit var ctl: Controller

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        AppState.load(this)
        ctl = Controller(this)
        Scheduler.scheduleOptimize(this)
        setContent { AsistenTheme { AsistenApp(ctl) } }
    }

    override fun onDestroy() {
        ctl.destroy()
        super.onDestroy()
    }
}
