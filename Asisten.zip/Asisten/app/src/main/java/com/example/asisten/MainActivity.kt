package com.example.asisten

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import kotlinx.coroutines.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val scope = MainScope()
    private lateinit var brain: Brain
    private lateinit var log: TextView
    private lateinit var input: EditText
    private lateinit var scroll: ScrollView
    private var tts: TextToSpeech? = null
    private var sr: SpeechRecognizer? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        brain = Brain(this); tts = TextToSpeech(this, this)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 48, 24, 24) }
        scroll = ScrollView(this); log = TextView(this).apply { textSize = 16f }
        scroll.addView(log); root.addView(scroll, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        input = EditText(this).apply { hint = "Ketik / Type…" }
        val row = LinearLayout(this)
        row.addView(input, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        fun btn(t: String, f: () -> Unit) = row.addView(Button(this).apply { text = t; setOnClickListener { f() } }, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT))
        btn("➤") { val t = input.text.toString(); input.setText(""); if (t.isNotBlank()) send(t) }
        btn("🎤") { listen() }
        btn("📎") { pick(10) }
        btn("🖼") { pick(11) }
        root.addView(row); setContentView(root)

        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)
        Scheduler.scheduleOptimize(this)
        append("Asisten: Halo! / Hi! Coba: \"buka kamera\", \"cuaca di Tokyo\", \"remind me call mom at 18:30\", \"ingat bahwa kucing saya adalah Mimi\".")
    }

    override fun onInit(s: Int) { tts?.language = Locale("id", "ID") }

    private fun append(t: String) { log.append(t + "\n\n"); scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) } }

    private fun say(t: String) {
        append("Asisten: $t")
        tts?.language = if (brain.id) Locale("id", "ID") else Locale.US
        tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    private fun send(t: String) {
        append("Anda: $t")
        scope.launch { say(try { brain.handle(t) } catch (e: Exception) { "Error: ${e.message}" }) }
    }

    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { say("Izinkan mikrofon dulu."); return }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { say("Speech recognizer tidak tersedia."); return }
        sr?.destroy(); sr = SpeechRecognizer.createSpeechRecognizer(this)
        sr!!.setRecognitionListener(object : RecognitionListener {
            override fun onResults(r: Bundle?) { r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { send(it) } }
            override fun onError(e: Int) { append("(mic error $e)") }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        sr!!.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (brain.id) "id-ID" else "en-US")
            .putExtra(RecognizerIntent.EXTRA_ADDITIONAL_LANGUAGES, arrayOf("id-ID", "en-US")))
    }

    private fun pick(code: Int) = startActivityForResult(
        Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), code)

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val u: Uri = data?.data ?: return
        if (res != RESULT_OK) return
        if (req == 10) {
            brain.lastFile = u
            say("File ${Files.name(this, u)} diterima. Katakan \"ringkas\" atau \"analisis\". / File received. Say \"summarize\" or \"analyze\".")
        } else if (req == 11) scope.launch {
            val r = withContext(Dispatchers.Default) { try { Photo.process(this@MainActivity, u) } catch (e: Exception) { "ERR|${e.message}" } }
            val (p, n) = r.split("|")
            say(if (p == "ERR") "Gagal memproses foto: $n (format RAW mungkin tidak didukung perangkat)."
            else "Foto diperbaiki dan disimpan: $p. Foto yang dipelajari: $n.")
        }
    }

    override fun onDestroy() { scope.cancel(); sr?.destroy(); tts?.shutdown(); super.onDestroy() }
}
