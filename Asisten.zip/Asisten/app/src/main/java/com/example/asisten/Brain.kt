package com.example.asisten

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar

/** Deteksi bahasa sederhana: Indonesia / Inggris. */
object Lang {
    private val idW = setOf("apa","buka","cuaca","di","dan","yang","ingat","tolong","jadwal","cari","ringkas",
        "ingatkan","bagaimana","berapa","siapa","pukul","jam","saya","itu","adalah","analisis","untuk")
    private val enW = setOf("what","open","weather","in","and","the","remember","please","schedule","search",
        "summarize","remind","how","who","at","me","is","analyze","for","launch")
    fun isId(t: String, prev: Boolean): Boolean {
        val w = t.lowercase().split(Regex("\\W+"))
        val a = w.count { it in idW }; val b = w.count { it in enW }
        return if (a == b) prev else a > b
    }
}

/** Memori belajar: user mengajarkan fakta baru, disimpan permanen. */
class Memory(ctx: Context) {
    private val sp = ctx.getSharedPreferences("mem", Context.MODE_PRIVATE)
    fun put(k: String, v: String) = sp.edit().putString(k.lowercase().trim(), v.trim()).apply()
    fun find(text: String): Pair<String, String>? =
        sp.all.entries.firstOrNull { text.lowercase().contains(it.key) }?.let { it.key to it.value.toString() }
}

class Brain(private val ctx: Context) {
    private val mem = Memory(ctx)
    var lastFile: Uri? = null
    var id = true

    suspend fun handle(raw: String): String = withContext(Dispatchers.IO) {
        val t = raw.trim(); val low = t.lowercase()
        id = Lang.isId(t, id)
        fun s(i: String, e: String) = if (id) i else e

        // 8. Belajar
        Regex("(?:ingat(?: bahwa)?|remember(?: that)?)\\s+(.+?)\\s+(?:adalah|is)\\s+(.+)", RegexOption.IGNORE_CASE).find(t)?.let {
            mem.put(it.groupValues[1], it.groupValues[2])
            return@withContext s("Oke, saya belajar: ${it.groupValues[1]} adalah ${it.groupValues[2]}.",
                "Got it, I learned: ${it.groupValues[1]} is ${it.groupValues[2]}.")
        }
        // 5. Jadwal / notifikasi
        Regex("(?:ingatkan|remind)(?: me| saya)?\\s+(.+?)\\s+(?:pukul|jam|at)\\s+(\\d{1,2})[:.](\\d{2})", RegexOption.IGNORE_CASE).find(t)?.let {
            val (msg, h, m) = it.destructured
            return@withContext Scheduler.schedule(ctx, msg, h.toInt(), m.toInt(), id)
        }
        // 3 & 12. Buka aplikasi
        Regex("^(?:buka|open|launch|jalankan)\\s+(.+)$", RegexOption.IGNORE_CASE).find(t)?.let {
            val name = it.groupValues[1].removePrefix("aplikasi ").removePrefix("app ").trim()
            return@withContext if (Tools.openApp(ctx, name)) s("Membuka $name.", "Opening $name.")
            else s("Aplikasi $name tidak ditemukan.", "App $name not found.")
        }
        // 4. Cuaca dunia
        Regex("(?:cuaca|weather)\\s*(?:di|in|for|untuk)?\\s*(.*)", RegexOption.IGNORE_CASE).find(t)?.let {
            val city = it.groupValues[1].trim()
            return@withContext if (city.isEmpty()) s("Kota mana?", "Which city?") else Tools.weather(city, id)
        }
        // 6 & 14. Analisis / ringkas file
        if (Regex("ringkas|rangkum|summar|analisis|analy[sz]e").containsMatchIn(low)) {
            val u = lastFile ?: return@withContext s("Lampirkan file dulu (tombol 📎).", "Attach a file first (📎).")
            val text = Files.extract(ctx, u)
                ?: return@withContext s("Format tidak didukung. Dukungan: PDF, PPTX, XLSX, TXT/CSV/MD/JSON.",
                    "Unsupported format. Supported: PDF, PPTX, XLSX, TXT/CSV/MD/JSON.")
            return@withContext if (Regex("analisis|analy").containsMatchIn(low)) Files.analyze(ctx, u, text, id)
            else Files.summarize(text, id)
        }
        // 8. Cek memori
        mem.find(t)?.let { return@withContext "${it.first}: ${it.second}" }
        // 2. Cari di internet (otomatis sebagai fallback)
        val q = t.replace(Regex("^(cari|search|siapa|who is|apa itu|what is)\\s+", RegexOption.IGNORE_CASE), "")
        Tools.search(q, id)
    }
}
