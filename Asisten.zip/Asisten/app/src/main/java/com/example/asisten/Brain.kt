package com.example.asisten

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Deteksi bahasa sederhana: Indonesia / Inggris. */
object Lang {
    private val idW = setOf("apa","buka","cuaca","di","dan","yang","ingat","tolong","jadwal","cari","ringkas",
        "ingatkan","bagaimana","berapa","siapa","pukul","jam","saya","itu","adalah","analisis","untuk","buat","gambar","berita")
    private val enW = setOf("what","open","weather","in","and","the","remember","please","schedule","search",
        "summarize","remind","how","who","at","me","is","analyze","for","launch","create","image","news")
    fun isId(t: String, prev: Boolean): Boolean {
        val w = t.lowercase().split(Regex("\\W+"))
        val a = w.count { it in idW }
        val b = w.count { it in enW }
        return if (a == b) prev else a > b
    }
}

/** Memori belajar: user mengajarkan fakta baru, disimpan permanen. */
class Memory(ctx: Context) {
    private val sp = ctx.getSharedPreferences("mem", Context.MODE_PRIVATE)
    fun put(k: String, v: String) = sp.edit().putString(k.lowercase().trim(), v.trim()).apply()
    fun all(): String = sp.all.entries.joinToString("; ") { "${it.key} = ${it.value}" }
    fun find(text: String): Pair<String, String>? =
        sp.all.entries.firstOrNull { text.lowercase().contains(it.key) }?.let { it.key to it.value.toString() }
}

class Brain(private val ctx: Context) {
    private val mem = Memory(ctx)
    var lastFile: Uri? = null
    var id = true

    private fun s(i: String, e: String) = if (id) i else e

    private val imgRx = Regex(
        "^(?:tolong\\s+)?(?:buat(?:kan)?|bikin(?:kan)?|generate|create|draw|make|gambar(?:kan)?|lukis(?:kan)?)\\s+" +
        "(?:saya\\s+|me\\s+)?(?:sebuah\\s+|an?\\s+)?(?:gambar|foto|image|picture|photo|ilustrasi|illustration)\\s*" +
        "(?:tentang|of|dari|about)?\\s*(.*)$", RegexOption.IGNORE_CASE)
    private val vidRx = Regex(
        "^(?:tolong\\s+)?(?:buat(?:kan)?|bikin(?:kan)?|generate|create|make)\\s+.*\\b(?:video|animasi|animation|klip|clip)\\b",
        RegexOption.IGNORE_CASE)
    private val tsRx = Regex(
        "\\b(?:terbaru|berita|hari ini|sekarang|harga|skor|latest|news|today|current|price|score|cari|search|siapa|who is|kapan|when|apa itu|what is|20\\d\\d)\\b",
        RegexOption.IGNORE_CASE)

    /** Jawaban berbasis pencarian web (DuckDuckGo/Bing/Wikipedia) + ringkasan oleh model bila ada. */
    private suspend fun webAnswer(q: String): String {
        if (!Net.online(ctx)) return s("Tidak ada koneksi internet.", "No internet connection.")
        val hits = Search.all(q, id)
        if (hits.isEmpty()) return s("Tidak ada hasil untuk \"$q\".", "No results for \"$q\".")
        val sources = hits.take(3).joinToString("\n") { "• " + it.url }
        if (Llm.available(ctx)) {
            try {
                val ans = Llm.chat(ctx, q, mem.all(), id, extra = Search.context(hits))
                return ans + "\n\n" + s("Sumber:", "Sources:") + "\n" + sources
            } catch (e: Throwable) { /* jatuh ke daftar hasil */ }
        }
        return hits.take(4).joinToString("\n\n") { "• ${it.title}\n${it.snippet}\n${it.url}" }
    }

    suspend fun handle(raw: String): String = withContext(Dispatchers.IO) {
        val t = raw.trim()
        id = Lang.isId(t, id)

        // Belajar
        Regex("(?:ingat(?: bahwa)?|remember(?: that)?)\\s+(.+?)\\s+(?:adalah|is)\\s+(.+)", RegexOption.IGNORE_CASE).find(t)?.let {
            mem.put(it.groupValues[1], it.groupValues[2])
            return@withContext s("Oke, saya belajar: ${it.groupValues[1]} adalah ${it.groupValues[2]}.",
                "Got it, I learned: ${it.groupValues[1]} is ${it.groupValues[2]}.")
        }
        // Jadwal / notifikasi
        Regex("(?:ingatkan|remind)(?: me| saya)?\\s+(.+?)\\s+(?:pukul|jam|at)\\s+(\\d{1,2})[:.](\\d{2})", RegexOption.IGNORE_CASE).find(t)?.let {
            val (msg, h, m) = it.destructured
            return@withContext Scheduler.schedule(ctx, msg, h.toInt(), m.toInt(), id)
        }
        // Buka aplikasi
        Regex("^(?:buka|open|launch|jalankan)\\s+(.+)$", RegexOption.IGNORE_CASE).find(t)?.let {
            val name = it.groupValues[1].removePrefix("aplikasi ").removePrefix("app ").trim()
            return@withContext if (Tools.openApp(ctx, name)) s("Membuka $name.", "Opening $name.")
            else s("Aplikasi $name tidak ditemukan.", "App $name not found.")
        }
        // Gambar generatif (dengan riset referensi otomatis)
        imgRx.find(t)?.let {
            val subj = it.groupValues[1].trim()
            return@withContext if (subj.isEmpty()) s("Gambar apa yang ingin dibuat?", "What image should I create?")
            else ImageGen.generate(ctx, subj, id)
        }
        // Video: belum didukung
        if (vidRx.containsMatchIn(t)) {
            return@withContext s("Pembuatan video AI belum didukung di versi ini (butuh server GPU/API khusus). Saya bisa membuat gambar: coba \"buat gambar ...\".",
                "AI video generation isn't supported in this version (it needs GPU servers/a dedicated API). I can create images: try \"create an image of ...\".")
        }
        // Cuaca dunia
        Regex("(?:cuaca|weather)\\s*(?:di|in|for|untuk)?\\s*(.*)", RegexOption.IGNORE_CASE).find(t)?.let {
            val tail = it.groupValues[1].trim()
            val city = Regex("(?:di|in|for|untuk)\\s+(.+)$", RegexOption.IGNORE_CASE).find(tail)?.groupValues?.get(1)?.trim() ?: tail
            return@withContext if (city.isEmpty()) s("Kota mana?", "Which city?") else Tools.weather(city, id)
        }
        // Analisis / ringkas file
        if (Regex("ringkas|rangkum|summar|analisis|analy[sz]e", RegexOption.IGNORE_CASE).containsMatchIn(t)) {
            val u = lastFile ?: return@withContext s("Lampirkan file dulu (tombol 📎).", "Attach a file first (📎).")
            val text = Files.extract(ctx, u)
                ?: return@withContext s("Format tidak didukung. Dukungan: PDF, PPTX, XLSX, TXT/CSV/MD/JSON.",
                    "Unsupported format. Supported: PDF, PPTX, XLSX, TXT/CSV/MD/JSON.")
            return@withContext if (Regex("analisis|analy", RegexOption.IGNORE_CASE).containsMatchIn(t)) Files.analyze(ctx, u, text, id)
            else Files.summarize(text, id)
        }

        // Pencarian web / jawaban generatif
        val q = t.replace(Regex("^(cari|search)\\s+", RegexOption.IGNORE_CASE), "")
        val hasModel = Llm.available(ctx)
        if (!hasModel || tsRx.containsMatchIn(t)) {
            if (!hasModel) mem.find(t)?.let { return@withContext "${it.first}: ${it.second}" }
            return@withContext webAnswer(q)
        }
        try {
            Llm.chat(ctx, t, mem.all(), id)
        } catch (e: Throwable) {
            s("Model gagal dimuat: ${e.message}", "Model failed to load: ${e.message}")
        }
    }
}
