package com.example.asisten

import android.content.Context
import android.os.Environment
import java.io.File
import java.net.URLEncoder
import kotlin.random.Random

/**
 * Pembuat gambar AI (cloud, tanpa API key via Pollinations) dengan riset referensi otomatis:
 * 1) cari referensi di web, 2) ambil kata kunci visual, 3) pelajari & simpan,
 * 4) padukan dengan selera foto pengguna, 5) (opsional) model lokal menyusun prompt, 6) generate.
 */
object ImageGen {
    private fun learn(ctx: Context, kws: List<String>) {
        val sp = ctx.getSharedPreferences("imgref", Context.MODE_PRIVATE)
        val e = sp.edit()
        kws.forEach { e.putInt(it, sp.getInt(it, 0) + 1) }
        e.apply()
    }

    private fun learned(ctx: Context, n: Int): List<String> {
        val sp = ctx.getSharedPreferences("imgref", Context.MODE_PRIVATE)
        return sp.all.entries.sortedByDescending { (it.value as? Int) ?: 0 }.take(n).map { it.key }
    }

    fun generate(ctx: Context, subject: String, id: Boolean): String {
        if (!Net.online(ctx)) return if (id) "Tidak ada koneksi internet untuk membuat gambar." else "No internet connection to generate images."

        // 1-2. Riset referensi otomatis
        val hits = try { Search.all("$subject reference photo", false).take(4) } catch (e: Exception) { emptyList() }
        val kws = Files.keywords(hits.joinToString(" ") { it.title + " " + it.snippet }, 6)
        learn(ctx, kws)

        // 3-4. Selera pengguna dari foto yang pernah diberikan
        val ps = ctx.getSharedPreferences("photo_style", Context.MODE_PRIVATE)
        val mood = if (ps.getInt("n", 0) >= 3) {
            val lum = ps.getFloat("lum", 0.5f)
            if (lum < 0.4f) "moody low-key lighting" else if (lum > 0.6f) "bright airy lighting" else "natural lighting"
        } else "natural lighting"

        var prompt = listOf(subject, kws.joinToString(", "), learned(ctx, 3).joinToString(", "), mood, "highly detailed, sharp focus")
            .filter { it.isNotBlank() }.joinToString(", ")

        // 5. Model lokal (jika ada) menyusun prompt Inggris yang lebih baik
        if (Llm.available(ctx)) {
            prompt = try {
                Llm.once(ctx, "Write ONE English image-generation prompt (max 50 words) for: \"$subject\". " +
                    "Use these visual hints if useful: ${kws.joinToString(", ")}; $mood. Output only the prompt.").take(400)
            } catch (e: Throwable) { prompt }
        }

        // 6. Generate
        val url = "https://image.pollinations.ai/prompt/" + URLEncoder.encode(prompt.take(500), "UTF-8") +
            "?width=768&height=768&nologo=true&seed=" + Random.nextInt(1, 999999)
        val bytes = try { Http.image(url) } catch (e: Exception) { null }
            ?: return if (id) "Gagal membuat gambar (server sibuk atau koneksi lambat). Coba lagi." else "Image generation failed (server busy or slow connection). Try again."

        val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_PICTURES)!!
        val f = File(dir, "gen_${System.currentTimeMillis()}.jpg")
        f.writeBytes(bytes)
        val ref = hits.firstOrNull()?.url
        val cap = (if (id) "Gambar dibuat dengan prompt:\n" else "Image created with prompt:\n") + prompt +
            (if (ref != null) (if (id) "\n\nReferensi: " else "\n\nReference: ") + ref else "")
        return "[[img:${f.absolutePath}]]$cap"
    }
}
